import fs from 'node:fs/promises';
import postgres from 'postgres';

const url=process.env.DATABASE_URL;
if(!url) throw new Error('DATABASE_URL is missing');
const sql=postgres(url,{max:1});
try{
  const schema=await fs.readFile(new URL('../db/schema.sql',import.meta.url),'utf8');
  const statements=schema.split(/;\s*(?:\n|$)/).map(x=>x.trim()).filter(Boolean);
  for(const statement of statements) await sql.unsafe(statement);
  console.log(`COLONY database schema applied successfully (${statements.length} statements).`);
}finally{await sql.end();}
